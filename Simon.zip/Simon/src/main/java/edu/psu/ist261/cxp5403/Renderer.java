/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.psu.ist261.cxp5403;

/**
 *
 * @author chasepflueger
 */
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class Renderer extends JPanel {
        @Override
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		if (Simon.simon != null)
		{
			Simon.simon.paint((Graphics2D) g);
		}
	}
}
